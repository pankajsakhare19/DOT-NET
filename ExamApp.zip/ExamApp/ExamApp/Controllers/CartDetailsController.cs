﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using BLL;
namespace ExamApp.Controllers
{
    public class CartDetailsController : Controller
    {
       public ActionResult ShowCart()
        {
            CartDtls cds= this.HttpContext.Session["cart"] as CartDtls;
            return View(cds.pizzaList);
        }

        public ActionResult ProceedToPay()
        {
            return RedirectToAction("ProceedToPay", "Details");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using BLL;
namespace ExamApp.Controllers
{
    
    public class DetailsController : Controller
    {
        // GET: Details
        public ActionResult Index()
        {
           List<PizzaDtls> pizzas= PizzaService.getAllPizzaDetails();
            ViewData["pizzas"]=pizzas;
            return View();
        }

        public ActionResult Details(int id)
        {
            PizzaDtls p = PizzaService.getPizza(id);
            ViewData["pizza"]= p;
            return View();
        }

        public ActionResult AddToCart(int id)
        {
            

            CartDtls cart = this.HttpContext.Session["cart"] as CartDtls;

            cart.pizzaList.Add(PizzaService.getPizza(id));
            
            return RedirectToAction("ShowCart","CartDetails");
        }

        public ActionResult ProceedToPay()
        {
            
            return View();
        }

        public ActionResult LogOut()
        {
            this.HttpContext.Session.Abandon();

            return RedirectToAction("Index","Home");
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;
namespace ExamApp.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin

        public ActionResult AdminHome()
        {
            if(TempData.ContainsKey("msg"))
            {
                ViewData["msg"] = TempData["msg"];
            }
            return View();
        }

        public ActionResult AdminIndex()
        {
            return View();
        }

       [HttpPost]
        public ActionResult AdminIndex(string PName, string PDesc, string PType, string Price )
        {
            PizzaDtls pizza = new PizzaDtls
            {

                PName = PName,
                PDesc = PDesc,
                PType = PType,
                Price = double.Parse(Price)

            };

            if(UserService.AddPizza(pizza))
            {
                ViewBag.message = "Added successfully";
                return View();

            }
            else
            return View();
        }

        public ActionResult PizzaDtls()
        {
            ViewData["pizzas"] = PizzaService.getAllPizzaDetails();
            return View();
        }


        public ActionResult RemoveDtls(int id)
        {
            if(PizzaService.deletePizza(id))
            {
                TempData["msg"] = "Deleted Successfully!!";
                return RedirectToAction("AdminHome", "Admin");
            }
            return View();
        }


        public ActionResult UpdateDtls(int id)
        {
            ViewData["pizzaUpdate"] = PizzaService.getPizza(id);
            return View();
        }

        [HttpPost]
        public ActionResult UpdateDtls(string id, string price)
        {
            if(PizzaService.updatePizza(new PizzaDtls(Convert.ToInt32(id), Convert.ToDouble(price))))
            {
                TempData["msg"] = "Updated Successfully!!";
                return RedirectToAction("AdminHome", "Admin");
            }

            return View();
        }

    }
}
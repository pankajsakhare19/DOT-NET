﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using DAL;
using BLL;
namespace ExamApp.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            
            return View();
        }

        [HttpPost]
        public ActionResult Index(string email, string password)
        {
            User u = UserService.validateUser(email, password);
            if (u != null && u.Role.Equals("normal"))
            {

                return RedirectToAction("index", "details");
            }

           else  if (u != null && u.Role.Equals("admin"))
            {

                return RedirectToAction("AdminHome", "admin");
            }

            return View();
        }
    }
}
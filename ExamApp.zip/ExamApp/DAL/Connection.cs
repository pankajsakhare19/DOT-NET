﻿using System;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BOL;
using System.Collections.Generic;

namespace DAL
{
    public class Connection
    {
        private static string connString = ConfigurationManager.ConnectionStrings["ExamDb"].ConnectionString;
        public static User Authenticate(string email, string password)
        {

            User u = new User() ;

            string query = "SELECT * FROM UserTable WHERE email=@email and password=@password";
            
            IDbConnection con = new SqlConnection();
            con.ConnectionString = connString;

            IDbCommand cmd = new SqlCommand(query, con as SqlConnection);
          

            cmd.Parameters.Add(new SqlParameter("@email", email));
            cmd.Parameters.Add(new SqlParameter("@password", password));

            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    u.Email = reader["email"].ToString();
                    u.Role = reader["role"].ToString();
                }

            }
            catch (SqlException se)
            {
                Console.WriteLine(se);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


            return u;


        }


        public static List<PizzaDtls> FetchPizzaDetails()
        {
            List<BOL.PizzaDtls> pizzas = new List<BOL.PizzaDtls>();

            string query = "select * from pizzaDtls";

            IDbConnection con = new SqlConnection();
            con.ConnectionString = connString;
            IDbCommand cmd = new SqlCommand(query, con as SqlConnection);

            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    pizzas.Add(new PizzaDtls(
                        Convert.ToInt32( reader["id"]),
                        reader["pname"].ToString(), 
                        reader["pdesc"].ToString(),
                        reader["ptype"].ToString(),
                        Convert.ToDouble( reader["price"])));

                }

            }
            catch (SqlException se)
            {
                Console.WriteLine(se);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


            return pizzas;
        }

        public static PizzaDtls getPizzaDetail(int id)
        {
            string query = "select * from pizzaDtls where Id=@id";
            PizzaDtls p = null;
            IDbConnection con = new SqlConnection();
            con.ConnectionString = connString;
            IDbCommand cmd = new SqlCommand(query, con as SqlConnection);

            cmd.Parameters.Add(new SqlParameter("@id", id));
            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                  p=new PizzaDtls(
                        Convert.ToInt32(reader["Id"]),
                        reader["pname"].ToString(),
                        reader["pdesc"].ToString(),
                        reader["ptype"].ToString(),
                        Convert.ToDouble(reader["price"]));

                }

            }
            catch (SqlException se)
            {
                Console.WriteLine(se);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p;
        }
    }
}

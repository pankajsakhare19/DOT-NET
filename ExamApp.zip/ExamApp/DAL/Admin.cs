﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    
    public class Admin
    {

        public static string connString = ConfigurationManager.ConnectionStrings["ExamDb"].ConnectionString;
        public static bool AddPizza(PizzaDtls pizza)
        {
            bool status = false; 

            string query = "insert into pizzaDtls(pname,pdesc,ptype,price) values (@pname,@pdesc, @ptype,@price);";

            IDbConnection con = new SqlConnection();
            con.ConnectionString = connString;

            IDbCommand cmd = new SqlCommand(query, con as SqlConnection);


            cmd.Parameters.Add(new SqlParameter("@pname", pizza.PName));
            cmd.Parameters.Add(new SqlParameter("@pdesc", pizza.PDesc));
            cmd.Parameters.Add(new SqlParameter("@ptype", pizza.PType));
            cmd.Parameters.Add(new SqlParameter("@price", pizza.Price));

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                status = true;

            }
            catch (SqlException se)
            {
                Console.WriteLine(se);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


           
            return status;
        }

        public static bool DeletePizza(int id)
        {
            bool status = false;
            string query = "DELETE FROM pizzaDtls WHERE Id=@id;";

            IDbConnection con = new SqlConnection();
            con.ConnectionString = connString;

            IDbCommand cmd = new SqlCommand(query, con as SqlConnection);


            cmd.Parameters.Add(new SqlParameter("@id", id));
            try
            {
                con.Open();
                int x=cmd.ExecuteNonQuery();
                if (x > 0)
                {
                    status = true;
                }
                

            }
            catch (SqlException se)
            {
                Console.WriteLine(se);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return status;
        }

        public static bool UpdatePizzaPrice(PizzaDtls pd)
        {
            bool status = false;
            string query = "UPDATE pizzaDtls set price=@price WHERE Id=@id;";

            IDbConnection con = new SqlConnection();
            con.ConnectionString = connString;

            IDbCommand cmd = new SqlCommand(query, con as SqlConnection);

            cmd.Parameters.Add(new SqlParameter("@price", pd.Price));
            cmd.Parameters.Add(new SqlParameter("@id", pd.Id));

            try
            {
                con.Open();
                int x = cmd.ExecuteNonQuery();
                if (x > 0)
                {
                    status = true;
                }


            }
            catch (SqlException se)
            {
                Console.WriteLine(se);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return status;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOL
{
    public class PizzaDtls
    {
        public PizzaDtls()
        {

        }

        public PizzaDtls(int id,string pname, string pdesc, string ptype, double price)
        {
            Id = id;
            PName = pname;
            PDesc = pdesc;
            PType = ptype;
            Price = price;
        }

        public PizzaDtls(int id, double price)
        {
            Id = id;
            Price = price;
        }

        public int Id { get; set; }
        public string PName { get; set; }
        public string PDesc { get; set; }

        public string PType { get; set; }

        public double Price { get; set; }
    }
}

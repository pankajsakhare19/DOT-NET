﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DAL;
using BOL;
namespace Day6.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(String UserName, String Password)
        {
            if(LoginManager.Validate(UserName, Password))
            {
                return RedirectToAction("index", "students");
            }
            else
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Register(string UserName, string Password)
        {
            StudentLogin newStu = new StudentLogin
            {
                UserName = UserName,
                Password = Password
            };

            if (LoginManager.Register(newStu))
            {
                return RedirectToAction("login");
            }
            else
            {
                return View();
            }
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using BLL;


namespace Day6.Controllers
{
    public class StudentsController : Controller
    {
        // GET: Students
        public ActionResult Index()
        {
            IEnumerable<Student> students = TrainingManager.GetStudents();
            return View(students);
        }

        public ActionResult Details(int id)
        {
            Student stu = TrainingManager.GetStudent(id);
            return View(stu);
        }
    }
}
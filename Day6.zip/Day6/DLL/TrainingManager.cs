﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;
namespace BLL
{
    public class TrainingManager
    {
        public static List<Student> GetStudents()
        {
            List<Student> students = TraningRepository.GetAll();
            return students;
        }

        public static Student GetStudent(int id)
        {
            Student student = TraningRepository.Get(id);
            return student;
        }
    }
}

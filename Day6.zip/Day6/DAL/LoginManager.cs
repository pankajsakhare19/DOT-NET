﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using BOL;

namespace DAL
{
    public static class LoginManager
    {
        public static string conString = string.Empty;
        static LoginManager()
        {
            conString = ConfigurationManager.ConnectionStrings["Database1"].ConnectionString;
        }

        public static bool Validate(string UserName, string Password)
        {
            bool status = false;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = conString;
            string cmdText = "select * from LoginStudent where UserName = @un and Password = @pas";
            SqlCommand cmd = new SqlCommand(cmdText, con);
            cmd.Parameters.Add(new SqlParameter("@un", UserName));
            cmd.Parameters.Add(new SqlParameter("@pas",Password));


            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();
                if(reader.Read())
                {
                    status = true;
                }
               
            }
            catch (SqlException exp)
            {
                throw exp;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return status;
        }

        public static bool Register(StudentLogin newStu)
        {
            bool status = false;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = conString;
            string cmdText = "INSERT INTO LoginStudent(username, password) VALUES(@UserName,@Password)";
            SqlCommand cmd = new SqlCommand(cmdText, con);
            cmd.Parameters.Add(new SqlParameter("@UserName", newStu.UserName));
            cmd.Parameters.Add(new SqlParameter("@Password", newStu.Password));
            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                status = true;
            }
            catch (SqlException exp)
            {
                throw exp;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                    con.Close();
            }

            return status;

        }
    }
}

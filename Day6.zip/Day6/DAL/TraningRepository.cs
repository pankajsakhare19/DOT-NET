﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BOL;
namespace DAL
{
    public class TraningRepository
    {
        public static string conString = string.Empty;
        static TraningRepository()
        {
            conString = ConfigurationManager.ConnectionStrings["Database1"].ConnectionString; ;
        }
        public static List<Student> GetAll()
        {
            List<Student> students = new List<Student>();

            string cmdText = "select * from students";

            IDbConnection con = new SqlConnection();
            con.ConnectionString = conString;

            IDbCommand cmd = new SqlCommand(cmdText, con as SqlConnection);
            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    Student stu = new Student();
                    stu.Id = int.Parse(reader["Id"].ToString());
                    stu.FirstName = reader["FirstName"].ToString();
                    stu.LastName = reader["LastName"].ToString();
                    stu.ContactNumber = reader["ContactNumber"].ToString();
                    stu.Email = reader["Email"].ToString();
                    stu.City = reader["City"].ToString();
                    students.Add(stu);

                }
                reader.Close();
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return students;
        }

        public static Student Get(int id)
        {
            Student stu = new Student();
            string cmdText = "select * from students where Id=" + id;
            IDbConnection con = new SqlConnection();
            con.ConnectionString = conString;
            IDbCommand cmd = new SqlCommand(cmdText, con as SqlConnection);
            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();
                if(reader.Read())
                {
                    stu.Id = int.Parse(reader["Id"].ToString());
                    stu.FirstName = reader["FirstName"].ToString();
                    stu.LastName = reader["LastName"].ToString();
                    stu.ContactNumber = reader["ContactNumber"].ToString();
                    stu.Email = reader["Email"].ToString();
                    stu.City = reader["City"].ToString();
                }
            }
            catch (SqlException exp)
            {

            }
            finally
            {
                if(con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return stu;
        }
    }
}

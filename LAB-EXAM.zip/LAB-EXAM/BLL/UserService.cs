﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;
namespace BLL
{
    public class UserService
    {
        public static User Validate(string email, string password)
        {
            User user = UserRepo.GetUser(email);
            if (user != null && user.Password==password)
            {
                return user;
            }
            else
            {
                return null;
            }
        }
    }
}

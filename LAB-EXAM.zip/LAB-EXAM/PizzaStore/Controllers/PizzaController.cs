﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using BLL;
namespace PizzaStore.Controllers
{
    public class PizzaController : Controller
    {
        // GET: Pizza
        public ActionResult Index()
        {
            List<Pizza> pizzas = PizzaService.GetAllPizzas();
            ViewData["username"] = ((User)Session["user"]).Email;
            ViewData["isAdmin"] = ((User)Session["user"]).Role;
            return View(pizzas);
        }

        public ActionResult Details(int id)
        {
            Pizza pizza = new Pizza();
            List<Pizza> model = PizzaService.GetAllPizzas();
            foreach (Pizza p in model)
            {
                if (p.Id == id)
                {
                    ViewData["pizzaUpdate"] = p;
                    return View();
                }
            }

            return View();
        }





        [HttpPost]
        public ActionResult Edit(int id, double price)
        {
            if(PizzaService.UpdatePizza(null))
            {
                return RedirectToAction("Pizza");
            }
            return View();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;

namespace PizzaStore.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Details(int id)
        {
            Pizza pizza = new Pizza();
            List<Pizza> model = (List<Pizza>)Session["cart"];
            foreach (Pizza p in model)
            {
                if (p.Id == id)
                {
                    ViewData["pizzaUpdate"] = p;
                    return View();
                }
            }

            return View();
        }
    }
}
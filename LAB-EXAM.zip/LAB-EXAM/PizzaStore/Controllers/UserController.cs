﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BOL;
using BLL;
namespace PizzaStore.Controllers
{
    public class UserController : Controller
    {
        // GET: User
        public ActionResult Login()
        {
            User model = new User();
            return View(model);
        }

        [HttpPost]
        public ActionResult Login(string email, string password)
        {
            User user = UserService.Validate(email,password);
            if(user != null)
            {
                ViewData["LoggedIn"] = "true";
                Session["user"] = user;
                return RedirectToAction("Index","Pizza");
            }
            ViewData["statud"] = "Invalid email or password";
            return View();
        }

        public ActionResult Logout()
        {
            User model = new User();
            Session["user"] = null;
            ViewData["LoggedIn"] = "false";
            return RedirectToAction("login", "User");
        }


        public ActionResult AddToCart(Pizza pizza)
        {
            ((List<Pizza>)Session["cart"]).Add(pizza);
            return RedirectToAction("Index", "Pizza");
        }

        // View Cart
        public ActionResult ViewCart()
        {
            List<Pizza> model = (List<Pizza>)Session["cart"];
            return View(model);
        }

        public ActionResult Delete(int id)
        {
            List<Pizza> model = (List<Pizza>)Session["cart"];
            foreach(Pizza p in model)
            {
                if(p.Id==id)
                {
                    model.Remove(p);
                    return RedirectToAction("ViewCart","User") ;
  
                }
            }
            return View();
        }

        public ActionResult Details(int id)
        {
            Pizza pizza = new Pizza();
            List<Pizza> model = (List<Pizza>)Session["cart"];
            foreach(Pizza p in model)
            {
                if(p.Id==id)
                {
                    ViewData["pizzaUpdate"] = p;
                    return View();
                }
            }

            return View();
        }

    }
}
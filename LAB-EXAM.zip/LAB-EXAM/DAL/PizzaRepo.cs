﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class PizzaRepo
    {
        public static String connString = string.Empty;
        static PizzaRepo()
        {
            connString = ConfigurationManager.ConnectionStrings["PizzaStore"].ConnectionString;
        }

        // Get all pizzas
        public static List<Pizza> GetPizzas()
        {
            List<Pizza> pizzas = new List<Pizza>();

            string cmdText = "SELECT * FROM Pizza";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = connString;

            SqlCommand cmd = new SqlCommand(cmdText, conn as SqlConnection);

            try
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Pizza pizza = new Pizza();
                    pizza.Id = Int32.Parse(reader["Id"].ToString());
                    pizza.Name = reader["name"].ToString();
                    pizza.Description = reader["description"].ToString();
                    pizza.Type = reader["type"].ToString();
                    pizza.Price = Double.Parse(reader["price"].ToString());

                    pizzas.Add(pizza);
                }
                reader.Close();
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }

            return pizzas;

        }

        public static bool UpdatePizzaPrice(Pizza pd)
        {
            bool status = false;
            string query = "UPDATE Pizza set price=@price WHERE Id=@id;";

            IDbConnection con = new SqlConnection();
            con.ConnectionString = connString;

            IDbCommand cmd = new SqlCommand(query, con as SqlConnection);

            cmd.Parameters.Add(new SqlParameter("@price", pd.Price));
            cmd.Parameters.Add(new SqlParameter("@id", pd.Id));

            try
            {
                con.Open();
                int x = cmd.ExecuteNonQuery();
                if (x > 0)
                {
                    status = true;
                }


            }
            catch (SqlException se)
            {
                Console.WriteLine(se);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

            return status;
        }
    }
}

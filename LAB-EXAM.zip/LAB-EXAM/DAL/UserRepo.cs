﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using BOL;
namespace DAL
{
    public class UserRepo
    {
        public static string conString = string.Empty;

        static UserRepo()
        {
            conString = ConfigurationManager.ConnectionStrings["PizzaStore"].ConnectionString;
        }

        public static User GetUser(String email)
        {
            User user = null;
            string cmdText = "SELECT * FROM Users WHERE email = @email";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = conString;
            SqlCommand cmd = new SqlCommand(cmdText,conn as SqlConnection);
            cmd.Parameters.AddWithValue("email",email);
  
            try
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    user = new User();
                    user.Email = reader["email"].ToString();
                    user.Password = reader["password"].ToString();
                    user.Role = reader["role"].ToString();
                }
                reader.Close();
            }
            catch (SqlException e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }
            return user;
        }
    }
}

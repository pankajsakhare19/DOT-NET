﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;
namespace BLL
{
    public class UserService
    {
        public static UserPOCO Authenticate(string email, string pass)
        {
            return UserRepo.Authenticate(email,pass);
        }
    }
}

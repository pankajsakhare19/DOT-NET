﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace DAL
{
    public class UserRepo
    {
        private static string connString = ConfigurationManager.ConnectionStrings["DBUtils"].ConnectionString;

        public static UserPOCO Authenticate(string email, string password)
        {

            UserPOCO u = new UserPOCO();

            string query = "SELECT * FROM UserDtls WHERE email=@email and password=@password";

            IDbConnection con = new SqlConnection();
            con.ConnectionString = connString;

            IDbCommand cmd = new SqlCommand(query, con as SqlConnection);


            cmd.Parameters.Add(new SqlParameter("@email", email));
            cmd.Parameters.Add(new SqlParameter("@password", password));

            try
            {
                con.Open();
                IDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    u.Email = reader["email"].ToString();
                    u.Role = reader["role"].ToString();
                }

            }
            catch (SqlException se)
            {
                Console.WriteLine(se);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }


            return u;


        }
    }
}
